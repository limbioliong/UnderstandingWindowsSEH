// TestSEH03.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <winnt.h>





#define DISPLAY_EXCEPTION_INFO(pExceptionRecord) \
    printf("An excepton occured at address : [0x%p]. Exception Code : [0x%08X]. Exception Flags : [0x%08X]\r\n", \
        pExceptionRecord->ExceptionAddress, \
        pExceptionRecord->ExceptionCode, \
        pExceptionRecord->ExceptionFlags); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_NONCONTINUABLE) /* 1 Noncontinuable exception */\
            printf(" EXCEPTION_NONCONTINUABLE\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_UNWINDING) /* 2 Unwind is in progress */ \
            printf(" EXCEPTION_UNWINDING\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_EXIT_UNWIND) /* 4 Exit unwind is in progress */ \
            printf(" EXCEPTION_EXIT_UNWIND\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_STACK_INVALID) /* 8 Stack out of limits or unaligned */ \
            printf(" EXCEPTION_STACK_INVALID\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_NESTED_CALL) /* 0x10 Nested exception handler call */ \
            printf(" EXCEPTION_NESTED_CALL\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_TARGET_UNWIND) /* 0x20 Target unwind in progress */ \
            printf(" EXCEPTION_TARGET_UNWIND\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_COLLIDED_UNWIND) /* 0x40 Collided exception handler call */ \
            printf(" EXCEPTION_COLLIDED_UNWIND\r\n");





int g_iDividend = 1000;
int g_iDivisor = 0;





EXCEPTION_DISPOSITION NTAPI _Function_class_(EXCEPTION_ROUTINE) MyDivisionByZero01ExceptionRoutine
(
    _Inout_ struct _EXCEPTION_RECORD* pExceptionRecord,
    _In_ PVOID EstablisherFrame,
    _Inout_ struct _CONTEXT* pContextRecord,
    _In_ PVOID DispatcherContext
)
{
    DISPLAY_EXCEPTION_INFO(pExceptionRecord)

    return ExceptionContinueSearch;
}





int TestDivisionByZero01SEH()
{
    NT_TIB* TIB = (NT_TIB*)NtCurrentTeb();

    EXCEPTION_REGISTRATION_RECORD Registration;
    Registration.Handler = (PEXCEPTION_ROUTINE)(&MyDivisionByZero01ExceptionRoutine);
    Registration.Next = TIB->ExceptionList;
    TIB->ExceptionList = &Registration;

    int iValue = g_iDividend / g_iDivisor;

    TIB->ExceptionList = TIB->ExceptionList->Next;

    return iValue;
}





void DemoGlobalUnwinding()
{
    __try
    {        
        TestDivisionByZero01SEH();
    }
    __except(EXCEPTION_EXECUTE_HANDLER)
    {
        printf("Caught the exception in DemoGlobalUnwinding()\n");
    }
}





void ExceptionCausingFunction()
{
    int* pInt = NULL;
    *pInt = 100;
}





void DemoLocalUnwind()
{
    __try
    {
        printf("TryLevel == 0. ScopeEntry[0].\r\n");

        __try
        {
            printf("TryLevel == 1. ScopeEntry[1].\r\n");

            __try
            {
                printf("TryLevel == 2. ScopeEntry[2].\r\n");

                ExceptionCausingFunction();
            }
            __finally
            {
                printf("__finally for TryLevel == 2. ScopeEntry[2].\r\n");
            }
        }
        __finally
        {
            printf("__finally for TryLevel == 1. ScopeEntry[1].\r\n");
        }
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        printf("__except for TryLevel == 0. ScopeEntry[0].\r\n");
    }
}





int main()
{
    DemoLocalUnwind();

    DemoGlobalUnwinding();
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
