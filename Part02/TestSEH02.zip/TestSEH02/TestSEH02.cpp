// TestSEH02.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <windows.h>
#include <winnt.h>

int FilterFunction()
{
    return EXCEPTION_EXECUTE_HANDLER;
}

void DemoSEHScoping()
{
    printf("TryLevel == -1. No associated ScopeEntry.\r\n");

    __try
    {
        printf("TryLevel == 0. ScopeEntry[0].\r\n");

        __try
        {
            printf("TryLevel == 1. ScopeEntry[1].\r\n");

            __try
            {
                printf("TryLevel == 2. ScopeEntry[2].\r\n");

                int* pInt = NULL;
                *pInt = 100;
            }
            __finally
            {
                printf("__finally for TryLevel == 2. ScopeEntry[2].\r\n");
            }

        }
        __finally
        {
            printf("__finally for TryLevel == 1. ScopeEntry[1].\r\n");
        }
    }
    __except (FilterFunction())
    {
        printf("__except for TryLevel == 0. ScopeEntry[0].\r\n");
    }

    printf("TryLevel == -1. No associated ScopeEntry.\r\n");

    __try
    {
        printf("TryLevel == 3. ScopeEntry[3].\r\n");

        __try
        {
            printf("TryLevel == 4. ScopeEntry[4].\r\n");

            int* pInt = NULL;
            *pInt = 100;
        }
        __finally
        {
            printf("__finally for TryLevel == 4. ScopeEntry[4].\r\n");
        }
    }
    __except (FilterFunction())
    {
        printf("__except for TryLevel == 3. ScopeEntry[3].\r\n");
    }

    printf("TryLevel == -1. No associated ScopeEntry.\r\n");
}

void TestSEH()
{
    __try
    {
        __try
        {
            int* pInt = NULL;
            *pInt = 100;
        }
        __finally
        {
            printf("__finally @ TestSEH()\r\n");
        }
    }
    __except (FilterFunction())
    {
        printf("__except @ TestSEH()\r\n");
    }
}

int main()
{
    DemoSEHScoping();
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
