// TestSEH04.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <winnt.h>
#include <setjmpex.h>

#define DISPLAY_EXCEPTION_INFO(pExceptionRecord) \
    printf("An excepton occured at address : [0x%p]. Exception Code : [0x%08X]. Exception Flags : [0x%08X]\r\n", \
        pExceptionRecord->ExceptionAddress, \
        pExceptionRecord->ExceptionCode, \
        pExceptionRecord->ExceptionFlags); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_NONCONTINUABLE) /* 1 Noncontinuable exception */\
            printf(" EXCEPTION_NONCONTINUABLE\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_UNWINDING) /* 2 Unwind is in progress */ \
            printf(" EXCEPTION_UNWINDING\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_EXIT_UNWIND) /* 4 Exit unwind is in progress */ \
            printf(" EXCEPTION_EXIT_UNWIND\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_STACK_INVALID) /* 8 Stack out of limits or unaligned */ \
            printf(" EXCEPTION_STACK_INVALID\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_NESTED_CALL) /* 0x10 Nested exception handler call */ \
            printf(" EXCEPTION_NESTED_CALL\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_TARGET_UNWIND) /* 0x20 Target unwind in progress */ \
            printf(" EXCEPTION_TARGET_UNWIND\r\n"); \
\
        if (pExceptionRecord->ExceptionFlags & EXCEPTION_COLLIDED_UNWIND) /* 0x40 Collided exception handler call */ \
            printf(" EXCEPTION_COLLIDED_UNWIND\r\n");

jmp_buf mark;

typedef void (FAR WINAPI* VOIDPROC)();

struct SCOPETABLE_ENTRY
{
    int         EnclosingLevel;
    FARPROC     lpfnFilter;
    VOIDPROC    lpfnHandler;
};

typedef struct _EH4_EXCEPTION_REGISTRATION_RECORD
{
    PVOID                           SavedESP;
    PEXCEPTION_POINTERS             ExceptionPointers;
    EXCEPTION_REGISTRATION_RECORD   SubRecord;
    UINT_PTR                        EncodedScopeTable;
    ULONG                           TryLevel;
} EH4_EXCEPTION_REGISTRATION_RECORD, * PEH4_EXCEPTION_REGISTRATION_RECORD;

extern "C" void _local_unwind2
(
    EXCEPTION_REGISTRATION_RECORD * xr,
    int stop
);

int __stdcall MyFilter()
{
    printf("MyFilter()\r\n");

    return EXCEPTION_EXECUTE_HANDLER;
    //return EXCEPTION_CONTINUE_SEARCH;
}

void __stdcall MyHandler()
{
    printf("MyHandler()\r\n");
}

EXCEPTION_DISPOSITION NTAPI _Function_class_(EXCEPTION_ROUTINE) MyExceptionHandler
(
    _Inout_ struct _EXCEPTION_RECORD* pExceptionRecord,
    _In_ PVOID EstablisherFrame,
    _Inout_ struct _CONTEXT* pContextRecord,
    _In_ PVOID DispatcherContext
)
{
    DISPLAY_EXCEPTION_INFO(pExceptionRecord)

    PEH4_EXCEPTION_REGISTRATION_RECORD RegistrationNode =
        (PEH4_EXCEPTION_REGISTRATION_RECORD)
        ((PCHAR)EstablisherFrame -
            FIELD_OFFSET(EH4_EXCEPTION_REGISTRATION_RECORD, SubRecord));

    EXCEPTION_POINTERS exception_pointers;
    exception_pointers.ExceptionRecord = pExceptionRecord;
    exception_pointers.ContextRecord = pContextRecord;
    RegistrationNode->ExceptionPointers = &exception_pointers;

    int iCurrentTryLevel = RegistrationNode->TryLevel;
    SCOPETABLE_ENTRY* scopetable = (SCOPETABLE_ENTRY*)(RegistrationNode->EncodedScopeTable);
    
    if (pExceptionRecord->ExceptionFlags == 0)
    {
        int iFilterFuncRet = 0;

        for 
        (
            int i = iCurrentTryLevel; 
            i != -1; 
            i = scopetable[i].EnclosingLevel
        )
        {
            if (scopetable[i].lpfnFilter == NULL)
            {
                // The current TryLevel does not have an __except Filter Function.
                // We skip this TryLevel and continue to the TryLevel of the 
                // Enclosing __try block.
                continue;
            }

            iFilterFuncRet = scopetable[iCurrentTryLevel].lpfnFilter();

            switch (iFilterFuncRet)
            {
                case EXCEPTION_CONTINUE_SEARCH:
                {
                    // Move on to the next enclosing TryLevel's Scope Table.
                    continue;
                }

                case EXCEPTION_CONTINUE_EXECUTION:
                {
                    // The Filter has resolved the Exception Cause.
                    // We can now continue execution at the point 
                    // of the original Exception.
                    return ExceptionContinueExecution;
                }

                case EXCEPTION_EXECUTE_HANDLER:
                {
                    if (scopetable[iCurrentTryLevel].lpfnHandler != NULL)
                    {
                        // First do a Global Unwind. This is to inform all SEH Exception Handlers
                        // which have been installed -AFTER- the current SEH Handler to do Unwinding.
                        // 
                        // Here, RegistrationNode->SubRecord is the TIB's ExceptionList Item
                        // which points to the current SEH Exception Handler.
                        // 
                        // RtlUnwind() will perform the following :
                        // 1. Get each of these handlers to do Local Unwinding.
                        // 2. Uninstall each of these handlers off the TIB's ExceptionList.
                        // 
                        // Note that the first parameter indicates to RtlUnwind() to
                        // do Unwinding for all SEH Handlers -UP TO- the current SEH Handler.
                        //
                        RtlUnwind((EXCEPTION_REGISTRATION_RECORD*)(&(RegistrationNode->SubRecord)), NULL, pExceptionRecord, NULL);

                        // Do a local unwind up to the current TryLevel.
                        // Local unwinding is necessary for the SEH frame that contains a SEH Handler.
                        // This is because there could be a __finally block beneath the __except block.
                        _local_unwind2((EXCEPTION_REGISTRATION_RECORD*)(&(RegistrationNode->SubRecord)), iCurrentTryLevel);

                        // Execute the Exception 
                        scopetable[iCurrentTryLevel].lpfnHandler();

                        // Jump to the location of setjmp() 
                        // and never return.
                        longjmp(mark, -1);
                    }
                    else
                    {
                        continue;
                    }
                }
            }
        }
    }
    else if (pExceptionRecord->ExceptionFlags == EXCEPTION_UNWINDING)
    {
        _local_unwind2((EXCEPTION_REGISTRATION_RECORD*)(&(RegistrationNode->SubRecord)), -1);
    }

    return ExceptionContinueSearch;
}

void Foo()
{
    __try
    {
        int* pInt = NULL;
        *pInt = 100;
    }
    __finally
    {
        printf("__finally @ Foo()\r\n");
    }
}

void DoCustomExceptionHandling()
{
    NT_TIB* TIB = (NT_TIB*)NtCurrentTeb();

    SCOPETABLE_ENTRY scopeentry[1];
    scopeentry[0].EnclosingLevel = -1;
    scopeentry[0].lpfnFilter = MyFilter;
    scopeentry[0].lpfnHandler = MyHandler;

    EH4_EXCEPTION_REGISTRATION_RECORD Registration;
    Registration.EncodedScopeTable = (UINT_PTR)scopeentry;
    Registration.SubRecord.Handler = (PEXCEPTION_ROUTINE)(MyExceptionHandler);
    Registration.SubRecord.Next = TIB->ExceptionList;
    TIB->ExceptionList = &(Registration.SubRecord);

    // Exception raising code below.
    int jmpret = setjmp(mark);

    if (jmpret == 0)
    {
        // Raise the TryLevel.
        Registration.TryLevel = 0;
        // Exception raising code below.
        Foo();
    }
    else
    {
        printf("Exception occurred\r\n");
    }

    // Restore the TryLevel.
    Registration.TryLevel = -1;

    TIB->ExceptionList = TIB->ExceptionList->Next;    
}

int main()
{
    __try
    {
        DoCustomExceptionHandling();
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        printf("__except @ main()\r\n");
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
